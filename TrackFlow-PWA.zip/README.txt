# TrackFlow PWA

This folder is the PWA-ready version of TrackFlow.

## Files to upload to your web host

- `index.html` — the TrackFlow app
- `manifest.webmanifest` — makes it installable
- `sw.js` — offline caching/service worker
- `icons/icon-192.png`
- `icons/icon-512.png`

Keep the folder structure exactly as provided.

## Important

The site must be served over HTTPS for normal PWA installation and service-worker support. GitHub Pages, Netlify, Vercel, Cloudflare Pages and similar static hosts work.

Your current app's progress is stored locally in the browser. PWA installation does not automatically create cloud sync. For multi-device sync, a database/account system would need to be added later.

## Install after publishing

Open the HTTPS website in Chrome/Edge. Use the browser's **Install app** / **Add to Home screen** option.
